# Zou – Farm Landing Page

### Demo
* [Codepen](https://codepen.io/mustafadalga/pen/KKgYJxP) 
* [Github Pages](https://mustafadalga.github.io/farm-landing-page/)


### Used technologies
 * HTML5  
 * SCSS - CSS3
 * Pure JavaScript

#### Resource Sketch Design
 * https://uigarage.net/ui-kit/zou-farm-landing-page/
 
 #### ScreenCapture
 ![screencapture](https://user-images.githubusercontent.com/25087769/105427205-af700480-5c5d-11eb-80f9-b779df7f43ff.png)

